echo $RANDOM | tr '0-9' 'a-zA-z'
