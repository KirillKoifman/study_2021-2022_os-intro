command=""
while getopts :n: opt
do
    case $opt in
       n) command="$OPTARG";;
   esac
done
if test -f "/usr/share/man/man1/$command.1.gz"
then less /usr/share/man/man1/$command.1.gz
else
    echo "try again"
fi
