#include<stdio.h>

int main()
{
    int input_value=0;
    scanf("%d", &input_value);
    if (input_value==0) return 1;
      if (input_value>0) return 2;
	if (input_value<0) return 3;
	  else return 0;
}
