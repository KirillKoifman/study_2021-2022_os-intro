#!/bin/bash

echo "Input value: "
./lab11_22
case $? in
  1) echo "The value is equal 0";;
  2) echo "The value is more than 0";;
  3) echo "The value is less than 0";;
  0) echo "Try again";;  
esac
