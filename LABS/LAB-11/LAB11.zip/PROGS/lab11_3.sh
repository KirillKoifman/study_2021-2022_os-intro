#!/bin/bash

if [ -z "$1" ]; then
    echo "Amount: $0 <number>"
    exit 1
fi

rm -f *.tmp

for number in $(seq 1 $1); do
    touch "$number.tmp"
done
