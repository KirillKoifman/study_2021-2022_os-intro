#!/bin/bash
while getopts "i:o:p:C:n" option
do case $option in
       i) input_file=$OPTARG;;
       o) output_file=$OPTARG;;
       p) template=$OPTARG;;
       C) Copt="";;
       n) nopt="";;
   esac
done

grep -n "$template" "$input_file" > "$output_file"
