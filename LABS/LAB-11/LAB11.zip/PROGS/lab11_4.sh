#!/bin/bash

find $1 -mtime 0 -mtime -7 | xargs -o tar -cf arhive.tar
exit 0
